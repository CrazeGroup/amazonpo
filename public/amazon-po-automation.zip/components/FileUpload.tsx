import React, { useRef } from 'react';

interface FileUploadProps {
  label: string;
  subLabel?: string;
  accept?: string;
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
  required?: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ 
  label, 
  subLabel, 
  accept = ".xlsx, .xls", 
  onFileSelect, 
  selectedFile,
  required
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div className="flex flex-col gap-0.5">
      <label className="text-[10px] uppercase font-bold text-gray-500 flex justify-between tracking-wider">
        <span>{label} {required && <span className="text-red-500">*</span>}</span>
        {selectedFile && <span className="text-green-600 font-normal">Loaded</span>}
      </label>
      <div 
        onClick={() => inputRef.current?.click()}
        className={`
          border border-dashed rounded px-3 py-1.5 cursor-pointer transition-colors flex items-center justify-between
          ${selectedFile 
            ? 'border-green-400 bg-green-50' 
            : 'border-gray-300 hover:border-amazon-blue bg-white hover:bg-gray-50'}
        `}
      >
        <input 
          type="file" 
          ref={inputRef}
          accept={accept} 
          onChange={handleChange} 
          className="hidden" 
        />
        {selectedFile ? (
          <div className="flex items-center gap-2 text-green-700 w-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span className="font-medium truncate text-xs">{selectedFile.name}</span>
          </div>
        ) : (
          <div className="flex items-center justify-between w-full text-gray-400">
             <span className="text-xs font-medium text-amazon-light">Click to upload</span>
             {subLabel && <span className="text-[10px] hidden sm:inline opacity-70">{subLabel}</span>}
          </div>
        )}
      </div>
    </div>
  );
};